﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ui
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        BLL.USUARIO service = new BLL.USUARIO();

        private void button1_Click(object sender, EventArgs e)
        {
            BE.Usuario u = new BE.Usuario();
            u.Nombre = textBox1.Text;
            u.Apellido = textBox2.Text;
            service.Agregar(u);
            Refresh();
        }
        public void Refresh()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = service.Listar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BE.Usuario u = dataGridView1.CurrentRow.DataBoundItem as BE.Usuario;
            service.Eliminar(u);
            Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Refresh();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            BE.Usuario u = dataGridView1.CurrentRow.DataBoundItem as BE.Usuario;
            u.Nombre = textBox1.Text;
            u.Apellido = textBox2.Text;
            service.Modificar(u);
            Refresh();
        }
    }
}
