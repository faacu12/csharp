﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class USUARIO
    {
        DAL.MP_Alumno mapper = new DAL.MP_Alumno();
        public void Agregar(BE.Usuario usuario)
        {
            
            mapper.Agregar(usuario);
        }
        public List<BE.Usuario> Listar()
        {
            return mapper.Listar();
        }
        public void Eliminar(BE.Usuario usuario)
        {
            mapper.Eliminar(usuario);
        }
        public void Modificar(BE.Usuario usuario)
        {
            mapper.Modificar(usuario);
        }
    }
}
