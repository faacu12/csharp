﻿using BE;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class MP_Alumno : MAPPER<BE.Usuario>
    {
        public override int Agregar(Usuario obj)
        {
            acceso = new Acceso();
            acceso.Abrir();
            List<SqlParameter> parametros = new List<SqlParameter>();
            parametros.Add(acceso.CrearParametro("@nombre", obj.Nombre));
            parametros.Add(acceso.CrearParametro("@apellido", obj.Apellido));
            int res = acceso.Escribir("Insertar", parametros);
            acceso.Cerrar();
            return res;
        }

        public override int Eliminar(Usuario obj)
        {
            acceso = new Acceso();
            acceso.Abrir();
            List<SqlParameter> parametros = new List<SqlParameter>();
            parametros.Add(acceso.CrearParametro("@id", obj.Id));
            int res = acceso.Escribir("Eliminar", parametros);
            acceso.Cerrar();
            return res;
        }

        public override List<Usuario> Listar()
        {
            acceso = new Acceso();
            acceso.Abrir();
            List<BE.Usuario> usuarios = new List<BE.Usuario>();
            DataTable dt = acceso.Leer("Listar");
            foreach (DataRow r in dt.Rows)
            {
                BE.Usuario u = new BE.Usuario();
                u.Id = (Convert.ToInt32(r[0]));
                u.Nombre = r[1].ToString();
                u.Apellido = r[2].ToString();
                usuarios.Add(u);
            }
            acceso.Cerrar();
            return usuarios;
        }        

        public override int Modificar(Usuario obj)
        {
            acceso = new Acceso();
            acceso.Abrir();
            List<SqlParameter> parametros = new List<SqlParameter>();
            parametros.Add(acceso.CrearParametro("@id", obj.Id));
            parametros.Add(acceso.CrearParametro("@nombre", obj.Nombre));
            parametros.Add(acceso.CrearParametro("@apellido", obj.Apellido));
            int res = acceso.Escribir("Modificar", parametros);
            acceso.Cerrar();
            return res;
        }
    }
}
